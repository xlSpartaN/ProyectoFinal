package com.login;

import java.awt.Color;
import java.sql.*;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

/**
 * Clase que representa la interfaz de opciones del sistema.
 */
public class Opciones extends javax.swing.JFrame {

    private int sumatoriaDiscos = 0;
    private int sumatoriaVinilos = 0;
    private String idEmpleado;
    private String idProducto;

    /**
     * Constructor de la clase Opciones. Inicializa los componentes de la
     * interfaz y configura su ubicación. Muestra los productos, clientes,
     * ventas, y otras entidades en la interfaz.
     */
    public Opciones() {
        initComponents();
        setLocationRelativeTo(null);
        mostrarProductos();
        TablaClientes();
        mostrarVentas();
        mostrarIDClientes();
        obtenerNuevoIDVenta();
        mostrarFechaActual();
        calcularSumaExistencia();
        jLabel13.setText(String.valueOf(idEmpleado));
        mostrarCompras();
        obtenerNuevoIDCompra();
        mostrarIDProductos();
        mostrarIDProveedores();

    }

    /**
     * Método para establecer el ID del empleado actual.
     *
     * @param idEmpleado El ID del empleado.
     */
    public void setIdEmpleado(String idEmpleado) {
        this.idEmpleado = idEmpleado;
        jLabel13.setText(idEmpleado); //Mostar idEmpleado en ese label
    }

    /**
     * Método para mostrar los productos en la tabla jTable2.
     */
    public void mostrarProductos() {
        try {
            // Establecer conexión con la base de datos
            String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
            String usuarioDB = "sa";
            String contraseñaDB = "1234";

            Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

            // Llamar al procedimiento almacenado
            String query = "{CALL AllProductos}";
            CallableStatement stmt = con.prepareCall(query);
            ResultSet rs = stmt.executeQuery();

            // Crear el DefaultTableModel y configurar las columnas
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ID_Producto");
            model.addColumn("No_Serie");
            model.addColumn("Canciones");
            model.addColumn("Categoria");
            model.addColumn("Precio");
            model.addColumn("ExistenciaDiscos");
            model.addColumn("ExistenciaVinilos");

            // Recorrer el ResultSet y agregar las filas al DefaultTableModel
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("ID_Producto"),
                    rs.getString("No_Serie"),
                    rs.getString("Canciones"),
                    rs.getString("Categoria"),
                    rs.getDouble("Precio"),
                    rs.getInt("ExistenciaDiscos"),
                    rs.getInt("ExistenciaVinilos")
                });
            }

            // Asignar el DefaultTableModel
            jTable2.setModel(model);

            // Cerrar la conexión y liberar recursos
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Método para mostrar los clientes en la tabla jTable1.
     */
    private void TablaClientes() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID_Cliente");
        model.addColumn("Nombre");
        model.addColumn("TelefonoCliente");

        try {
            // Establecer la conexión con la base de datos SQL Server
            String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
            String usuarioDB = "sa";
            String contraseñaDB = "1234";
            Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

            // Llamar al procedimiento almacenado
            String query = "{CALL AllClientes}";
            CallableStatement stmt = conexión.prepareCall(query);
            ResultSet resultado = stmt.executeQuery();

            // Recorrer los resultados y agregarlos al modelo de la tabla
            while (resultado.next()) {
                String idCliente = resultado.getString("ID_Cliente");
                String nombre = resultado.getString("Nombre");
                String telefonoCliente = resultado.getString("TelefonoCliente");
                model.addRow(new Object[]{idCliente, nombre, telefonoCliente});
            }

            resultado.close();
            stmt.close();
            conexión.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        jTable1.setModel(model);
    }

    /**
     * Método para mostrar los clientes en la tabla jTable1.
     */
    public void mostrarVentas() {
        try {
            // Establecer conexión con la base de datos
            String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
            String usuarioDB = "sa";
            String contraseñaDB = "1234";

            Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

            // Llamar al procedimiento almacenado
            String query = "{CALL AllVentas}";
            CallableStatement stmt = con.prepareCall(query);
            ResultSet rs = stmt.executeQuery();

            // Crear el DefaultTableModel y configurar las columnas
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ID_Venta");
            model.addColumn("ID_Cliente");
            model.addColumn("ID_Empleado");
            model.addColumn("ID_Producto");
            model.addColumn("FechaVenta");
            model.addColumn("Cantidad");
            model.addColumn("Total");

            // Recorrer el ResultSet y agregar las filas al DefaultTableModel
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("ID_Venta"),
                    rs.getString("ID_Cliente"),
                    rs.getString("ID_Empleado"),
                    rs.getString("ID_Producto"),
                    rs.getString("FechaVenta"),
                    rs.getInt("Cantidad"),
                    rs.getDouble("Total")
                });
            }

            // Asignar el DefaultTableModel
            jTable3.setModel(model);

            // Cerrar la conexión y liberar recursos
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Método para mostrar las compras en la tabla jTable5.
     */
    public void mostrarCompras() {
        try {
            // Establecer conexión con la base de datos
            String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
            String usuarioDB = "sa";
            String contraseñaDB = "1234";

            Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

            // Llamar al procedimiento almacenado
            String query = "{CALL AllCompras}";
            CallableStatement stmt = con.prepareCall(query);
            ResultSet rs = stmt.executeQuery();

            // Crear el DefaultTableModel y configurar las columnas
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Id_Compra");
            model.addColumn("Id_Proveedor");
            model.addColumn("Id_Producto");
            model.addColumn("Cantidad");
            model.addColumn("Fecha");
            model.addColumn("Total");

            // Recorrer el ResultSet y agregar las filas al DefaultTableModel
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("Id_Compra"),
                    rs.getString("Id_Proveedor"),
                    rs.getString("Id_Producto"),
                    rs.getInt("Cantidad"),
                    rs.getDate("Fecha"),
                    rs.getDouble("Total")
                });
            }

            // Asignar el DefaultTableModel a la jTable5
            jTable5.setModel(model);

            // Cerrar la conexión y liberar recursos
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Muestra la fecha actual en el JLabel correspondiente.
     */
    public void mostrarFechaActual() {
        // Obtener la fecha actual
        LocalDate fechaActual = LocalDate.now();

        // Formatear la fecha como una cadena
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String fechaFormateada = fechaActual.format(formatter);

        // Mostrar la fecha 
        jLabel6.setText(fechaFormateada);
    }

    /**
     * Calcula la suma de la existencia de discos y vinilos.
     */
    public void calcularSumaExistencia() {
        DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
        int selectedRow = jTable4.getSelectedRow();
        double totalPrecio = 0.0;

        if (selectedRow != -1) {
            Object valor = model.getValueAt(selectedRow, 4);
            if (valor instanceof Number) {
                double precio = ((Number) valor).doubleValue();

                // Obtener los valores de las existencias de Discos y Vinilos
                Number existenciaDiscos = (Number) model.getValueAt(selectedRow, 5);
                Number existenciaVinilos = (Number) model.getValueAt(selectedRow, 6);

                // Obtener los valores de los multiplicadores
                String multiplicador1Text = jTextField5.getText();
                String multiplicador2Text = jTextField6.getText();

                boolean multiplicador1Valido = false;
                boolean multiplicador2Valido = false;
                double multiplicador1 = 0.0;
                double multiplicador2 = 0.0;

                // Verificar si el multiplicador 1 no está vacío y contiene al menos un dígito
                if (!multiplicador1Text.isEmpty() && multiplicador1Text.matches(".*\\d+.*")) {
                    multiplicador1 = Double.parseDouble(multiplicador1Text);
                    multiplicador1Valido = true;
                }

                // Verificar si el multiplicador 2 no está vacío y contiene al menos un dígito
                if (!multiplicador2Text.isEmpty() && multiplicador2Text.matches(".*\\d+.*")) {
                    multiplicador2 = Double.parseDouble(multiplicador2Text);
                    multiplicador2Valido = true;
                }

                // Verificar si ambos multiplicadores están vacíos o cero
                if ((!multiplicador1Valido && !multiplicador2Valido) || (multiplicador1 == 0 && multiplicador2 == 0)) {
                    JOptionPane.showMessageDialog(null, "Debe ingresar al menos un número en uno de las Casillas Disco/Vinilos.");
                } else {
                    // Verificar si los multiplicadores no superan las existencias
                    if (multiplicador1Valido && multiplicador1 <= existenciaDiscos.doubleValue()
                            && multiplicador2Valido && multiplicador2 <= existenciaVinilos.doubleValue()) {

                        // Realizar el cálculo según las condiciones
                        if (multiplicador1Valido && multiplicador2Valido) {
                            // Ambos multiplicadores son válidos, realizar el cálculo normal
                            double precioMultiplicado = precio * (multiplicador1 + multiplicador2);
                            totalPrecio = precioMultiplicado;
                        }

                        if (multiplicador1Valido && !multiplicador2Valido) {
                            // Solo multiplicador 1 es válido, multiplicar por el multiplicador 1 solamente
                            double precioMultiplicado = precio * multiplicador1;
                            totalPrecio = precioMultiplicado;
                        }

                        if (!multiplicador1Valido && multiplicador2Valido) {
                            // Solo multiplicador 2 es válido, multiplicar por el multiplicador 2 solamente
                            double precioMultiplicado = precio * multiplicador2;
                            totalPrecio = precioMultiplicado;
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "El valor del multiplicador excede la existencia disponible.");
                    }
                }
            }
        }

        // Mostrar el resultado en el jTextField7
        jTextField7.setText(String.valueOf(totalPrecio));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton12 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jButton16 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton17 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton18 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jPanel36 = new javax.swing.JPanel();
        jButton11 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jButton22 = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jButton23 = new javax.swing.JButton();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton25 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        jButton26 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(209, 255, 237));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton4.setBackground(new java.awt.Color(201, 232, 190));
        jButton4.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-album-64.png"))); // NOI18N
        jButton4.setText("Productos");
        jButton4.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton4MouseMoved(evt);
            }
        });
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton4MouseExited(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 150));

        jButton5.setBackground(new java.awt.Color(201, 232, 190));
        jButton5.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/pa5.png"))); // NOI18N
        jButton5.setText("Clientes");
        jButton5.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton5MouseMoved(evt);
            }
        });
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton5MouseExited(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, 170, 150));

        jButton6.setBackground(new java.awt.Color(201, 232, 190));
        jButton6.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-caja-registradora-50.png"))); // NOI18N
        jButton6.setText("Caja");
        jButton6.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton6MouseMoved(evt);
            }
        });
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton6MouseExited(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 170, 150));

        jButton21.setBackground(new java.awt.Color(201, 232, 190));
        jButton21.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-ventas-totales-64.png"))); // NOI18N
        jButton21.setText("Ventas");
        jButton21.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton21MouseMoved(evt);
            }
        });
        jButton21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton21MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton21MouseExited(evt);
            }
        });
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 0, 170, 150));

        jButton20.setBackground(new java.awt.Color(201, 232, 190));
        jButton20.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/carrito-de-compras.png"))); // NOI18N
        jButton20.setText("Compras");
        jButton20.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton20MouseMoved(evt);
            }
        });
        jButton20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton20MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton20MouseExited(evt);
            }
        });
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 0, 170, 150));

        jLabel1.setFont(new java.awt.Font("Microsoft Yi Baiti", 0, 36)); // NOI18N
        jLabel1.setText("-");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 0, -1, -1));

        jLabel2.setFont(new java.awt.Font("Microsoft Yi Baiti", 0, 36)); // NOI18N
        jLabel2.setText("X");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 0, -1, -1));

        jPanel7.setBackground(new java.awt.Color(199, 185, 255));

        jLabel3.setFont(new java.awt.Font("Corbel", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-notas-musicales-100.png"))); // NOI18N
        jLabel3.setText("Productos que tenemos");

        jLabel4.setBackground(new java.awt.Color(255, 153, 153));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        jPanel18.setBackground(new java.awt.Color(192, 77, 249));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton8.setBackground(new java.awt.Color(43, 209, 252));
        jButton8.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-pop-64.png"))); // NOI18N
        jButton8.setText("Pop");
        jButton8.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton8MouseMoved(evt);
            }
        });
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton8MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton8MouseExited(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 10, 202, 84));

        jButton1.setBackground(new java.awt.Color(43, 209, 252));
        jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-rock-64.png"))); // NOI18N
        jButton1.setText("Rock");
        jButton1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton1MouseMoved(evt);
            }
        });
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton1MouseExited(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 202, 84));

        jButton2.setBackground(new java.awt.Color(43, 209, 252));
        jButton2.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-bad-bunny-48.png"))); // NOI18N
        jButton2.setText("Regueton");
        jButton2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton2MouseMoved(evt);
            }
        });
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton2MouseExited(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(446, 10, 202, 84));

        jButton7.setBackground(new java.awt.Color(43, 209, 252));
        jButton7.setFont(new java.awt.Font("Microsoft YaHei", 1, 18)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-music-band-48.png"))); // NOI18N
        jButton7.setText("Banda");
        jButton7.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton7MouseMoved(evt);
            }
        });
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton7MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton7MouseExited(evt);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(677, 10, 202, 84));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID_Producto", "No_Serie", "Canciones", "Categoria", "Precio", "Discos", "Vinilos"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jButton12.setBackground(new java.awt.Color(43, 209, 252));
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-anterior (1).gif"))); // NOI18N
        jButton12.setText("Mostrar todos los productos");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton15.setBackground(new java.awt.Color(43, 209, 252));
        jButton15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-agregar-a-carrito-de-compras-64.png"))); // NOI18N
        jButton15.setText("Selecciona Productos a Comprar");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 885, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 292, Short.MAX_VALUE)))
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 221, Short.MAX_VALUE)
                .addGap(56, 56, 56))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(279, 279, 279)
                        .addComponent(jLabel3)
                        .addGap(90, 90, 90)
                        .addComponent(jButton12))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(jButton15)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(196, 196, 196)
                        .addComponent(jLabel4))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jButton12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton15)
                .addContainerGap(5311, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("tab1", jPanel7);

        jPanel4.setBackground(new java.awt.Color(199, 185, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Ventas"));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID_Venta", "ID_Cliente", "ID_Empleado", "ID_Producto", "FechaVenta", "Cantidad", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTable3);

        jButton3.setBackground(new java.awt.Color(43, 209, 252));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-anterior (1).gif"))); // NOI18N
        jButton3.setText("Actualizar Tabla");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel13.setBackground(new java.awt.Color(192, 77, 249));

        jLabel18.setFont(new java.awt.Font("Microsoft PhagsPa", 0, 14)); // NOI18N
        jLabel18.setText("ID_Venta:");

        jLabel21.setFont(new java.awt.Font("Microsoft PhagsPa", 0, 14)); // NOI18N
        jLabel21.setText("Fecha:");

        jLabel19.setText("Cantidad:");

        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 290, Short.MAX_VALUE)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField11))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel21)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel21)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(184, Short.MAX_VALUE))
        );

        jButton27.setBackground(new java.awt.Color(43, 209, 252));
        jButton27.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-búsqueda.gif"))); // NOI18N
        jButton27.setText("Consultar");
        jButton27.setMaximumSize(new java.awt.Dimension(137, 71));
        jButton27.setMinimumSize(new java.awt.Dimension(137, 71));
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        jButton28.setBackground(new java.awt.Color(43, 209, 252));
        jButton28.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-editar.gif"))); // NOI18N
        jButton28.setText("Editar");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(364, 364, 364)
                .addComponent(jButton3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton27, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3))
                .addGap(47, 47, 47))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton27, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 471, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 5255, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("tab4", jPanel10);

        jPanel3.setBackground(new java.awt.Color(199, 185, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Selecion de Productos Comprados"));
        jPanel3.setForeground(new java.awt.Color(255, 253, 222));

        jPanel5.setBackground(new java.awt.Color(199, 185, 255));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 975, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 355, Short.MAX_VALUE)
        );

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID_Producto", "No_Serie", "Canciones", "Categoria", "Precio", "ExistenciaDiscos", "ExistenciaVinilos"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(jTable4);

        jButton16.setBackground(new java.awt.Color(43, 209, 252));
        jButton16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-vaciar-carro-64.png"))); // NOI18N
        jButton16.setText("Eliminar Filas Seleccionadas del Carrito");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-cliente.gif"))); // NOI18N
        jLabel5.setText("Selecciona el ID del Cliente: ");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-boleto.gif"))); // NOI18N
        jLabel7.setText("ID_Venta:");

        jTextField4.setEditable(false);
        jTextField4.setText("jTextField4");
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-fecha.gif"))); // NOI18N
        jLabel8.setText("Fecha Acual:");

        jButton17.setBackground(new java.awt.Color(43, 209, 252));
        jButton17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-pago-en-línea.gif"))); // NOI18N
        jButton17.setText("Comprar");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/reproductor-de-cd.png"))); // NOI18N
        jLabel9.setText("Discos:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/vinilo.png"))); // NOI18N
        jLabel10.setText("Vinilos:");

        jTextField5.setText("0");
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });

        jTextField6.setText("0");
        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-monedas-64.png"))); // NOI18N
        jLabel11.setText("Precio:");

        jTextField7.setEditable(false);
        jTextField7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("ID_Empleado:");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jButton18.setBackground(new java.awt.Color(43, 209, 252));
        jButton18.setText("Confirmar");
        jButton18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton18MouseClicked(evt);
            }
        });
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jButton24.setBackground(new java.awt.Color(43, 209, 252));
        jButton24.setText("...");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton24)
                                .addGap(112, 112, 112)
                                .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton17)
                                .addGap(105, 105, 105))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(55, 55, 55))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jTextField5, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                                                    .addComponent(jTextField6)))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                                .addGap(179, 179, 179)
                                                .addComponent(jButton18)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 247, Short.MAX_VALUE)))
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 921, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(641, 641, 641)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton16)
                            .addComponent(jLabel5)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton24))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(30, 30, 30)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel11)
                                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(54, 54, 54)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(3, 3, 3)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(108, 108, 108)
                                        .addComponent(jButton18))))))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 136, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 1027, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 433, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(5153, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("tab3", jPanel9);

        jPanel12.setBackground(new java.awt.Color(199, 185, 255));

        jPanel37.setBackground(new java.awt.Color(199, 185, 255));
        jPanel37.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos"));

        jLabel30.setFont(new java.awt.Font("Microsoft PhagsPa", 0, 14)); // NOI18N
        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-huella-dactilar.gif"))); // NOI18N
        jLabel30.setText("ID:");

        jLabel31.setFont(new java.awt.Font("Microsoft PhagsPa", 0, 14)); // NOI18N
        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-nombre.gif"))); // NOI18N
        jLabel31.setText("Nombre:");

        jLabel32.setFont(new java.awt.Font("Microsoft PhagsPa", 0, 14)); // NOI18N
        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-mensaje-de-telefono.gif"))); // NOI18N
        jLabel32.setText("Telefono:");

        jPanel36.setBackground(new java.awt.Color(192, 77, 249));
        jPanel36.setBorder(javax.swing.BorderFactory.createTitledBorder("Opciones"));

        jButton11.setBackground(new java.awt.Color(43, 209, 252));
        jButton11.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/Add_User-80_icon-icons.com_57380.png"))); // NOI18N
        jButton11.setText("Agregar ");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(43, 209, 252));
        jButton10.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-buscar-cliente-64.png"))); // NOI18N
        jButton10.setText("Consultar");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton13.setBackground(new java.awt.Color(43, 209, 252));
        jButton13.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/businessapplication_edit_male_user_thepencil_theclient_negocio_2321.png"))); // NOI18N
        jButton13.setText("Modificar");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setBackground(new java.awt.Color(43, 209, 252));
        jButton14.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/delete_delete_deleteusers_delete_male_user_maleclient_2348.png"))); // NOI18N
        jButton14.setText("Eliminar");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(505, 505, 505))
        );

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-anterior (1).gif"))); // NOI18N
        jButton9.setText("Regresar a la Tabla");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Base de Datos"));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID_Cliente", "Nombre", "TelefonoCliente"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 857, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 67, Short.MAX_VALUE)))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 463, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                    .addContainerGap(18, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(312, 312, 312)))
        );

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField1)
                    .addComponent(jTextField2)
                    .addComponent(jTextField3))
                .addGap(165, 165, 165)
                .addComponent(jButton9)
                .addGap(257, 257, 257))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel37Layout.createSequentialGroup()
                .addComponent(jPanel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9))
                .addGap(24, 24, 24)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(132, 132, 132))
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(504, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(4875, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("tab2", jPanel12);

        jPanel8.setBackground(new java.awt.Color(199, 185, 255));

        jPanel11.setBackground(new java.awt.Color(199, 185, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Compras"));

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "id_Compra", "id_Proveedor", "id_Producto", "Cantidad", "Fecha", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(jTable5);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("id_Compra:");

        jTextField8.setEditable(false);
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("id_Proveedor:");

        jButton19.setBackground(new java.awt.Color(43, 209, 252));
        jButton19.setText("...");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("id_Producto:");

        jButton22.setBackground(new java.awt.Color(43, 209, 252));
        jButton22.setText("...");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setText("cantidad:");

        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jButton23.setBackground(new java.awt.Color(43, 209, 252));
        jButton23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton23.setText("Agregar");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jButton25.setBackground(new java.awt.Color(43, 209, 252));
        jButton25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-anterior (1).gif"))); // NOI18N
        jButton25.setText("Actualizar Tabla");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setText("ID_Compra A Buscar:");

        jPanel14.setBackground(new java.awt.Color(192, 77, 249));

        jButton26.setBackground(new java.awt.Color(43, 209, 252));
        jButton26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/icons8-búsqueda.gif"))); // NOI18N
        jButton26.setText("Consultar Compra");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(355, Short.MAX_VALUE)
                .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(336, 336, 336))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 892, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 30, Short.MAX_VALUE))
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(157, 157, 157)
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel11Layout.createSequentialGroup()
                                        .addComponent(jButton25)
                                        .addGap(157, 157, 157)
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel11Layout.createSequentialGroup()
                                        .addGap(389, 389, 389)
                                        .addComponent(jButton23))))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton19))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton22)
                                .addGap(94, 94, 94)
                                .addComponent(jLabel20)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addComponent(jButton25)
                        .addGap(35, 35, 35))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)))
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jButton19)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton23)
                .addGap(10, 10, 10)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton22)
                    .addComponent(jLabel20)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(503, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 5293, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("tab6", jPanel8);

        jPanel2.setBackground(new java.awt.Color(199, 185, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1460, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5841, Short.MAX_VALUE)
        );

        jTabbedPane4.addTab("tab5", jPanel2);

        jPanel1.add(jTabbedPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 1460, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        this.setExtendedState(1);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        jTabbedPane4.setSelectedIndex(0);
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton4MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseMoved
        jPanel2.setBackground(new Color(214, 180, 248));
    }//GEN-LAST:event_jButton4MouseMoved

    private void jButton4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseExited
        jPanel2.setBackground(new Color(242, 230, 255));
    }//GEN-LAST:event_jButton4MouseExited

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        jTabbedPane4.setSelectedIndex(3);
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton5MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseMoved
        jPanel2.setBackground(new Color(214, 180, 248));
    }//GEN-LAST:event_jButton5MouseMoved

    private void jButton5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseExited
        jPanel2.setBackground(new Color(242, 230, 255));
    }//GEN-LAST:event_jButton5MouseExited

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
        jTabbedPane4.setSelectedIndex(2);
    }//GEN-LAST:event_jButton6MouseClicked

    private void jButton6MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseMoved
        jPanel2.setBackground(new Color(214, 180, 248));
    }//GEN-LAST:event_jButton6MouseMoved

    private void jButton6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseExited
        jPanel2.setBackground(new Color(242, 230, 255));
    }//GEN-LAST:event_jButton6MouseExited
    /**
     * Acción ejecutada cuando se presiona el botón "Rock". Realiza una consulta
     * a la base de datos para seleccionar los registros de la tabla "Productos"
     * con categoría "Rock" y los muestra en la jTable2.
     */
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            // Establecer conexión con la base de datos
            String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
            String usuarioDB = "sa";
            String contraseñaDB = "1234";

            Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

            // Llamar al procedimiento almacenado
            String query = "{CALL ProductosRock}";
            CallableStatement stmt = con.prepareCall(query);
            ResultSet rs = stmt.executeQuery();

            // Crear el DefaultTableModel y configurar las columnas
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ID_Producto");
            model.addColumn("No_Serie");
            model.addColumn("Canciones");
            model.addColumn("Categoria");
            model.addColumn("Precio");
            model.addColumn("ExistenciaDiscos");
            model.addColumn("ExistenciaVinilos");

            // Recorrer el ResultSet y agregar las filas al DefaultTableModel
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("ID_Producto"),
                    rs.getString("No_Serie"),
                    rs.getString("Canciones"),
                    rs.getString("Categoria"),
                    rs.getDouble("Precio"),
                    rs.getInt("ExistenciaDiscos"),
                    rs.getInt("ExistenciaVinilos")
                });
            }

            // Asignar el DefaultTableModel a la JTable jTable2
            jTable2.setModel(model);

            // Cerrar la conexión y liberar recursos
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * Acción ejecutada cuando se presiona el botón "Regueton". Realiza una
     * consulta a la base de datos para seleccionar los registros de la tabla
     * "Productos" con categoría "Regueton" y los muestra en la jTable2.
     */
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            // Establecer conexión con la base de datos
            String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
            String usuarioDB = "sa";
            String contraseñaDB = "1234";

            Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

            // Llamar al procedimiento almacenado SeleccionarProductosRegueton
            String query = "{CALL ProductosRegueton}";

            CallableStatement stmt = con.prepareCall(query);
            ResultSet rs = stmt.executeQuery();

            // Crear el DefaultTableModel y configurar las columnas
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ID_Producto");
            model.addColumn("No_Serie");
            model.addColumn("Canciones");
            model.addColumn("Categoria");
            model.addColumn("Precio");
            model.addColumn("ExistenciaDiscos");
            model.addColumn("ExistenciaVinilos");

            // Recorrer el ResultSet y agregar las filas al DefaultTableModel
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("ID_Producto"),
                    rs.getString("No_Serie"),
                    rs.getString("Canciones"),
                    rs.getString("Categoria"),
                    rs.getDouble("Precio"),
                    rs.getInt("ExistenciaDiscos"),
                    rs.getInt("ExistenciaVinilos")
                });
            }

            // Asignar el DefaultTableModel a la JTable jTable2
            jTable2.setModel(model);

            // Cerrar la conexión y liberar recursos
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton2ActionPerformed
    /**
     * Acción ejecutada cuando se presiona el botón "Banda". Realiza una
     * consulta a la base de datos para seleccionar los registros de la tabla
     * "Banda" con categoría "Regueton" y los muestra en la jTable2.
     */
    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
try {
    // Establecer conexión con la base de datos
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";

    Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Llamar al procedimiento almacenado SeleccionarProductosBanda
    String query = "{CALL ProductosBanda}";

    CallableStatement stmt = con.prepareCall(query);
    ResultSet rs = stmt.executeQuery();

    // Crear el DefaultTableModel y configurar las columnas
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID_Producto");
    model.addColumn("No_Serie");
    model.addColumn("Canciones");
    model.addColumn("Categoria");
    model.addColumn("Precio");
    model.addColumn("ExistenciaDiscos");
    model.addColumn("ExistenciaVinilos");

    // Recorrer el ResultSet y agregar las filas al DefaultTableModel
    while (rs.next()) {
        model.addRow(new Object[]{
            rs.getString("ID_Producto"),
            rs.getString("No_Serie"),
            rs.getString("Canciones"),
            rs.getString("Categoria"),
            rs.getDouble("Precio"),
            rs.getInt("ExistenciaDiscos"),
            rs.getInt("ExistenciaVinilos")
        });
    }

    // Asignar el DefaultTableModel a la JTable jTable2
    jTable2.setModel(model);

    // Cerrar la conexión y liberar recursos
    rs.close();
    stmt.close();
    con.close();

} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
    }//GEN-LAST:event_jButton7ActionPerformed
    /**
     * Acción ejecutada cuando se presiona el botón "Pop". Realiza una consulta
     * a la base de datos para seleccionar los registros de la tabla "Pop" con
     * categoría "Regueton" y los muestra en la jTable2.
     */
    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
try {
    // Establecer conexión con la base de datos
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";

    Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Llamar al procedimiento almacenado SeleccionarProductosPop
    String query = "{CALL ProductosPop}";

    CallableStatement stmt = con.prepareCall(query);
    ResultSet rs = stmt.executeQuery();

    // Crear el DefaultTableModel y configurar las columnas
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID_Producto");
    model.addColumn("No_Serie");
    model.addColumn("Canciones");
    model.addColumn("Categoria");
    model.addColumn("Precio");
    model.addColumn("ExistenciaDiscos");
    model.addColumn("ExistenciaVinilos");

    // Recorrer el ResultSet y agregar las filas al DefaultTableModel
    while (rs.next()) {
        model.addRow(new Object[]{
            rs.getString("ID_Producto"),
            rs.getString("No_Serie"),
            rs.getString("Canciones"),
            rs.getString("Categoria"),
            rs.getDouble("Precio"),
            rs.getInt("ExistenciaDiscos"),
            rs.getInt("ExistenciaVinilos")
        });
    }

    // Asignar el DefaultTableModel a la JTable jTable2
    jTable2.setModel(model);

    // Cerrar la conexión y liberar recursos
    rs.close();
    stmt.close();
    con.close();

} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseClicked
    }//GEN-LAST:event_jButton8MouseClicked

    private void jButton8MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseMoved
    }//GEN-LAST:event_jButton8MouseMoved

    private void jButton8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseExited
    }//GEN-LAST:event_jButton8MouseExited

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseMoved
    }//GEN-LAST:event_jButton1MouseMoved

    private void jButton1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseExited
    }//GEN-LAST:event_jButton1MouseExited

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseMoved
    }//GEN-LAST:event_jButton2MouseMoved

    private void jButton2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseExited
    }//GEN-LAST:event_jButton2MouseExited

    private void jButton7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseClicked
    }//GEN-LAST:event_jButton7MouseClicked

    private void jButton7MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseMoved
    }//GEN-LAST:event_jButton7MouseMoved

    private void jButton7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseExited
    }//GEN-LAST:event_jButton7MouseExited
    /**
     * Acción ejecutada cuando se presiona el botón "Agregar Cliente". Obtiene
     * los datos del cliente ingresados en los campos de texto jTextField1,
     * jTextField2 y jTextField3. Verifica si hay campos vacíos y muestra un
     * mensaje de error si es necesario. Establece la conexión con la base de
     * datos y verifica si el ID del cliente y el número de teléfono ya existen
     * en la base de datos. Si no existen duplicados, inserta un nuevo cliente
     * en la tabla "Clientes" y muestra un mensaje de éxito. Actualiza los datos
     * en la tabla jTable1.
     */
    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        String idCliente = jTextField1.getText();
        String nombre = jTextField2.getText();
        String telefonoCliente = jTextField3.getText();

// Verificar si hay campos vacíos
        if (idCliente.isEmpty() || nombre.isEmpty() || telefonoCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            return;
        }

       try {
    // Establecer conexión con la base de datos SQL Server
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";
    Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Llamar al procedimiento almacenado InsertarCliente
    String procedimiento = "{CALL InsertarCliente(?, ?, ?)}";
    CallableStatement llamadaProcedimiento = conexión.prepareCall(procedimiento);
    llamadaProcedimiento.setString(1, idCliente);
    llamadaProcedimiento.setString(2, nombre);
    llamadaProcedimiento.setString(3, telefonoCliente);
    llamadaProcedimiento.execute();

    // Actualizar los datos de la tabla
    TablaClientes();

    JOptionPane.showMessageDialog(null, "Cliente agregado correctamente.");

    // Cerrar la conexión y liberar recursos
    llamadaProcedimiento.close();
    conexión.close();
} catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_jButton11ActionPerformed
    /**
     * Acción ejecutada cuando se presiona el botón "Buscar Cliente". Obtiene
     * los datos del cliente ingresados en los campos de texto jTextField1,
     * jTextField2 y jTextField3. Realiza una búsqueda en la base de datos según
     * los campos proporcionados (ID y/o nombre del cliente). Actualiza los
     * datos en la tabla jTable1 con los resultados de la búsqueda.
     */
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
try {
    // Establecer conexión con la base de datos SQL Server
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";
    Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Obtener los valores de los campos de búsqueda
    String idCliente = jTextField1.getText();
    String nombre = jTextField2.getText();

    // Llamar al procedimiento almacenado BuscarCliente
    String procedimiento = "{CALL BuscarCliente(?, ?)}";
    CallableStatement llamadaProcedimiento = conexión.prepareCall(procedimiento);
    llamadaProcedimiento.setString(1, idCliente.isEmpty() ? null : idCliente);
    llamadaProcedimiento.setString(2, nombre.isEmpty() ? null : nombre);
    ResultSet resultado = llamadaProcedimiento.executeQuery();

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);

    // Verificar si se encontraron clientes y agregarlos a la tabla
    if (resultado.next()) {
        do {
            String clienteId = resultado.getString("ID_Cliente");
            String clienteNombre = resultado.getString("Nombre");
            String clienteTelefono = resultado.getString("TelefonoCliente");
            model.addRow(new Object[]{clienteId, clienteNombre, clienteTelefono});
        } while (resultado.next());

        JOptionPane.showMessageDialog(null, "Cliente encontrado con éxito.");
    } else {
        JOptionPane.showMessageDialog(null, "No se encontraron clientes.");
    }

    // Cerrar la conexión y liberar recursos
    resultado.close();
    llamadaProcedimiento.close();
    conexión.close();
} catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_jButton10ActionPerformed
    /**
     * Acción ejecutada cuando se presiona el botón "Buscar Cliente". Obtiene
     * los datos del cliente ingresados en los campos de texto jTextField1,
     * jTextField2 y jTextField3. Realiza una búsqueda en la base de datos según
     * los campos proporcionados (ID y/o nombre del cliente). Actualiza los
     * datos en la tabla jTable1 con los resultados de la búsqueda.
     */
    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        String idCliente = jTextField1.getText();
        String nombre = jTextField2.getText();
        String telefonoCliente = jTextField3.getText();

// Verificar si el campo del ID está vacío
        if (idCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese el ID del cliente.");
            return;
        }

// Verificar si hay al menos 2 campos vacíos
        int camposVacios = 0;
        if (nombre.isEmpty()) {
            camposVacios++;
        }
        if (telefonoCliente.isEmpty()) {
            camposVacios++;
        }

        if (camposVacios >= 2) {
            JOptionPane.showMessageDialog(null, "Debe completar al menos 2 campos.");
            return;
        }

 try {
    // Establecer la conexión con la base de datos SQL Server
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";
    Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Verificar si el nombre del cliente ya existe en la base de datos
    String consultaVerificarNombre = "EXEC ActualizarCliente ?, ?, ?";
    PreparedStatement declaración = conexión.prepareStatement(consultaVerificarNombre);
    declaración.setString(1, idCliente);
    declaración.setString(2, nombre.isEmpty() ? null : nombre);
    declaración.setString(3, telefonoCliente.isEmpty() ? null : telefonoCliente);
    ResultSet resultado = declaración.executeQuery();

    // Verificar si se encontró el cliente y actualizar los datos de la tabla
    if (resultado.next()) {
        JOptionPane.showMessageDialog(null, resultado.getString(1));
    } else {
        JOptionPane.showMessageDialog(null, "No se encontró ningún cliente con el ID especificado.");
    }

    // Cerrar la conexión y liberar recursos
    resultado.close();
    declaración.close();
    conexión.close();
} catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, "Cliente Actualizado con extio.");
}

    }//GEN-LAST:event_jButton13ActionPerformed
    /**
     * Actualiza la tabla "Clientes" en jTable1 llamando al metodo.
     */
    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        TablaClientes();
    }//GEN-LAST:event_jButton9ActionPerformed
    /**
     * Elimina un cliente de la base de datos según el ID proporcionado en el
     * campo de texto jTextField1. Muestra un mensaje de éxito o error
     * dependiendo del resultado de la eliminación.
     */
    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        /*
        int filaSeleccionada = jTable1.getSelectedRow();

        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente de la tabla.");
        } else {
            String idCliente = (String) jTable1.getValueAt(filaSeleccionada, 0);
         */

try {
    // Establecer la conexión con la base de datos SQL Server
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";
    Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Obtener el ID del cliente desde el campo de texto
    String idCliente = jTextField1.getText();
    // Verificar si el campo del ID está vacío
    if (idCliente.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Por favor, ingrese el ID del cliente.");
        return;
    }

    // Llamar al procedimiento almacenado para eliminar el cliente
    String consultaEliminar = "EXEC EliminarCliente ?";
    PreparedStatement declaración = conexión.prepareStatement(consultaEliminar);
    declaración.setString(1, idCliente);
    int filasAfectadas = declaración.executeUpdate();

    // Verificar si se eliminó el cliente correctamente
    if (filasAfectadas > 0) {
        JOptionPane.showMessageDialog(null, "ID Cliente No existe.");
    } else {
        JOptionPane.showMessageDialog(null, "Cliente eliminado exitosamente.");
    }

    // Cerrar la conexión y liberar recursos
    declaración.close();
    conexión.close();
} catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed
    /**
     * Actualiza la tabla "mostrarProductos" en jTable2 llamando al metodo.
     */
    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        mostrarProductos();
    }//GEN-LAST:event_jButton12ActionPerformed
    /**
     * Copia las filas seleccionadas de la tabla jTable2 y las agrega a la tabla
     * jTable4. Calcula la suma de existencias después de copiar las filas.
     * Muestra mensajes de error si no se seleccionaron filas o si se intenta
     * seleccionar antes de realizar la primera compra.
     */
    public void copiarFilasSeleccionadas() {
        // Obtener el modelo de jTable4
        DefaultTableModel model = (DefaultTableModel) jTable4.getModel();

        // Verificar si jTable4 está vacía
        if (model.getRowCount() == 0) {
            // Obtener los índices de las filas seleccionadas en jTable2
            int[] seleccionarfila = jTable2.getSelectedRows();

            // Verificar si se ha seleccionado una única fila
            if (seleccionarfila.length > 0) {
                // Recorrer los índices de las filas seleccionadas y copiarlas
                for (int fila : seleccionarfila) {
                    // Obtener los valores de las celdas de la fila seleccionada
                    Object[] rowData = new Object[jTable2.getColumnCount()];
                    for (int i = 0; i < jTable2.getColumnCount(); i++) {
                        if (i == 5 || i == 6) { // Columnas de Discos y Vinilos
                            rowData[i] = jTable2.getValueAt(fila, i);
                        } else {
                            rowData[i] = jTable2.getValueAt(fila, i);
                        }
                    }

                    // Agregar la fila al modelo
                    model.addRow(rowData);
                }

                // Calcular la suma de existencias
                calcularSumaExistencia();
            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar por lo menos una única fila.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se puede seleccionar hasta que se haya realizado la primera compra.");
        }
    }


    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed

        copiarFilasSeleccionadas();

    }//GEN-LAST:event_jButton15ActionPerformed
    /**
     * Copia las filas seleccionadas de la tabla jTable2 y las agrega a la tabla
     * jTable4. Calcula la suma de existencias después de copiar las filas.
     * Muestra mensajes de error si no se seleccionaron filas o si se intenta
     * seleccionar antes de realizar la primera compra.
     */
    public void vaciarFilasSeleccionadas(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        int[] selectedRows = table.getSelectedRows();

        if (selectedRows.length > 0) {
            // Recorrer los índices de las filas seleccionadas en orden inverso
            for (int i = selectedRows.length - 1; i >= 0; i--) {
                model.removeRow(selectedRows[i]);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se han seleccionado filas a Eliminar.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        vaciarFilasSeleccionadas(jTable4);
    }//GEN-LAST:event_jButton16ActionPerformed
    /**
     * Obtiene los ID_Cliente desde la base de datos y los muestra en el
     * jComboBox1. Si ocurre un error al conectar con la base de datos, muestra
     * un mensaje de error.
     */
    public void mostrarIDClientes() {
try {
    // Establecer conexión con la base de datos
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";

    // Crear la conexión y preparar la llamada al procedimiento almacenado
    Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);
    CallableStatement cstmt = con.prepareCall("{call ObtenerIDClientes}");

    // Ejecutar la llamada al procedimiento almacenado
    ResultSet rs = cstmt.executeQuery();

    // Crear un modelo de ComboBox para almacenar los ID_Cliente
    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();

    // Recorrer el ResultSet y agregar los ID_Cliente al modelo
    while (rs.next()) {
        model.addElement(rs.getString("ID_Cliente"));
    }

    // Asignar el modelo al JComboBox1
    jComboBox1.setModel(model);

    // Cerrar la conexión y liberar recursos
    rs.close();
    cstmt.close();
    con.close();

} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }

    /**
     * Obtiene los ID_Producto desde la base de datos y los muestra en el
     * jComboBox2. Si ocurre un error al conectar con la base de datos, muestra
     * un mensaje de error.
     */
    public void mostrarIDProductos() {
try {
    // Establecer conexión con la base de datos
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";

    // Crear la conexión y preparar la llamada al procedimiento almacenado
    Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);
    CallableStatement cstmt = con.prepareCall("{call ObtenerIDProductos}");

    // Ejecutar la llamada al procedimiento almacenado
    ResultSet rs = cstmt.executeQuery();

    // Crear un modelo de ComboBox para almacenar los ID_Productos
    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();

    // Recorrer el ResultSet y agregar los ID_Productos al modelo
    while (rs.next()) {
        model.addElement(rs.getString("ID_Producto"));
    }

    // Asignar el modelo a alguna de las jComboBox
    jComboBox2.setModel(model);

    // Cerrar la conexión y liberar recursos
    rs.close();
    cstmt.close();
    con.close();

} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }

    /**
     * Obtiene los ID_Proveedor desde la base de datos y los muestra en el
     * JComboBox jComboBox3. Si ocurre un error al conectar con la base de
     * datos, muestra un mensaje de error.
     */
    public void mostrarIDProveedores() {
try {
    // Establecer conexión con la base de datos
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";

    // Crear la conexión y preparar la llamada al procedimiento almacenado
    Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);
    CallableStatement cstmt = con.prepareCall("{call ObtenerIDProveedores}");

    // Ejecutar la llamada al procedimiento almacenado
    ResultSet rs = cstmt.executeQuery();

    // Crear un modelo de ComboBox para almacenar los ID_Proveedor
    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();

    // Recorrer el ResultSet y agregar los ID_Proveedor al modelo
    while (rs.next()) {
        model.addElement(rs.getString("ID_Proveedor"));
    }

    // Asignar el modelo al JComboBox3
    jComboBox3.setModel(model);

    // Cerrar la conexión y liberar recursos
    rs.close();
    cstmt.close();
    con.close();

} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed
    /**
     * Obtiene el último ID_Venta registrado en la base de datos, genera un
     * nuevo ID_Venta incrementando en uno y lo muestra en el jTextField4. Si
     * ocurre un error al conectar con la base de datos, muestra un mensaje de
     * error.
     */
    public void obtenerNuevoIDVenta() {
try {
    // Establecer conexión con la base de datos
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";

    // Crear la conexión y preparar la llamada al procedimiento almacenado
    Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);
    CallableStatement cstmt = con.prepareCall("{call ObtenerUltimoIDVenta}");

    // Ejecutar la llamada al procedimiento almacenado
    ResultSet rs = cstmt.executeQuery();

    // Obtener el último ID_Venta y aumentarlo en uno
    String nuevoIDVenta = "V001"; // Valor predeterminado si no hay registros
    if (rs.next()) {
        String ultimoIDVenta = rs.getString("MaxIDVenta");
        if (ultimoIDVenta != null) {
            int numeroIDVenta = Integer.parseInt(ultimoIDVenta.substring(1));
            numeroIDVenta++; // Incrementar en uno

            // Formatear el número con ceros a la izquierda si es necesario
            if (numeroIDVenta < 10) {
                nuevoIDVenta = String.format("V00%d", numeroIDVenta);
            } else if (numeroIDVenta < 100) {
                nuevoIDVenta = String.format("V0%d", numeroIDVenta);
            } else {
                nuevoIDVenta = String.format("V%d", numeroIDVenta);
            }
        }
    }

    // Mostrar el nuevo ID_Venta en el JTextField4
    jTextField4.setText(nuevoIDVenta);

    // Cerrar la conexión y liberar recursos
    rs.close();
    cstmt.close();
    con.close();

} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }

    /**
     * Obtiene el último ID_Compra registrado en la base de datos, genera un
     * nuevo ID_Compra incrementando en uno y lo muestra en el jTextField8. Si
     * ocurre un error al conectar con la base de datos, muestra un mensaje de
     * error.
     */
    public void obtenerNuevoIDCompra() {
try {
    // Establecer conexión con la base de datos
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";

    // Crear la conexión y preparar la llamada al procedimiento almacenado
    Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);
    CallableStatement cstmt = con.prepareCall("{call ObtenerUltimoIDCompra}");

    // Ejecutar la llamada al procedimiento almacenado
    ResultSet rs = cstmt.executeQuery();

    // Obtener el último ID_Compra y aumentarlo en uno
    String nuevoIDCompra = "CM01"; // Valor predeterminado
    if (rs.next()) {
        String ultimoIDCompra = rs.getString("MaxIDCompra");
        if (ultimoIDCompra != null) {
            int numeroIDCompra = Integer.parseInt(ultimoIDCompra.substring(2));
            numeroIDCompra++; // Incrementar en uno

            // Formatear el número con ceros a la izquierda si es necesario
            if (numeroIDCompra < 10) {
                nuevoIDCompra = String.format("CM0%d", numeroIDCompra);
            } else {
                nuevoIDCompra = String.format("CM%d", numeroIDCompra);
            }
        }
    }

    // Mostrar el nuevo ID_Compra en el JTextField8
    jTextField8.setText(nuevoIDCompra);

    // Cerrar la conexión y liberar recursos
    rs.close();
    cstmt.close();
    con.close();

} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
    }

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed

    }//GEN-LAST:event_jTextField4ActionPerformed
    /**
     * Evento que se ejecuta al hacer clic en el botón jButton17. Realiza varias
     * validaciones y cálculos relacionados con la venta de productos. Si se
     * cumple todas las validaciones, agrega la venta a la base de datos y
     * elimina la línea seleccionada en jTable4. Si no se cumple alguna
     * validación, muestra mensajes de error correspondientes.
     */
    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
// Obtener los valores de los multiplicadores
        String multiplicador1Text = jTextField5.getText();
        String multiplicador2Text = jTextField6.getText();

        if (!jButton18Pressed) {
            JOptionPane.showMessageDialog(null, "Debes presionar el Boton Confirmar antes de realizar la compra.");
            return;
        }
// Verificar si los campos de multiplicadores están vacíos o son cero
        if (multiplicador1Text.isEmpty() && multiplicador2Text.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Los campos de Disco y Vinilos están vacíos.");
            return; // Salir del método sin realizar la compra
        }

// Verificar si los campos de multiplicadores son cero
        double multiplicador1 = Double.parseDouble(multiplicador1Text);
        double multiplicador2 = Double.parseDouble(multiplicador2Text);
        if (multiplicador1 == 0 && multiplicador2 == 0) {
            JOptionPane.showMessageDialog(null, "Los campos de Disco y Vinilos no pueden ser cero.");
            return; // Salir del método sin realizar la compra
        }

// Realizar los cálculos y actualizar el jTextField7
        calcularSumaExistencia();

        String idVenta = jTextField4.getText(); // ID_Venta obtenido del jTextField4
        String idCliente = jComboBox1.getSelectedItem().toString(); // ID_Cliente obtenido del jComboBox1
        String idEmpleado = jLabel13.getText(); // ID_Empleado obtenido del jLabel13

// Verificar si hay una fila seleccionada en jTable4
        int selectedRow = jTable4.getSelectedRow();
        if (selectedRow != -1) {
            // Obtener el valor de la celda en la columna 0 de la fila seleccionada
            String idProducto = jTable4.getValueAt(selectedRow, 0).toString();

            mostrarFechaActual(); // Obtener la fecha actual y establecerla en jLabel6

            int cantidad = Integer.parseInt(jTextField5.getText()) + Integer.parseInt(jTextField6.getText()); // Suma de jTextField5 y jTextField6 para obtener la Cantidad
            double total = Double.parseDouble(jTextField7.getText()); // Total obtenido del jTextField7

            // Crear la consulta SQL INSERT
            String query = "INSERT INTO Ventas (ID_Venta, ID_Cliente, ID_Empleado, ID_Producto, FechaVenta, Cantidad, Total) VALUES (?, ?, ?, ?, ?, ?, ?)";

            try {
                String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
                String usuarioDB = "sa";
                String contraseñaDB = "1234";
                Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);
                PreparedStatement statement = con.prepareStatement(query);
                statement.setString(1, idVenta);
                statement.setString(2, idCliente);
                statement.setString(3, idEmpleado);
                statement.setString(4, idProducto);
                statement.setString(5, jLabel6.getText()); // Obtener la fecha de jLabel6
                statement.setInt(6, cantidad);
                statement.setDouble(7, total);
                statement.executeUpdate();
                JOptionPane.showMessageDialog(null, "Venta agregada correctamente a la base de datos.");
                statement.close();
                con.close();
                // Eliminar la línea seleccionada en jTable4
                DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
                model.removeRow(selectedRow);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al agregar la venta a la base de datos: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se ha seleccionado ninguna fila.");
        }
    }//GEN-LAST:event_jButton17ActionPerformed
    /* 
    private void restarValores() {
        // Obtener el valor de JTextFIeld5
        String Discos = jTextField5.getText();
        int valorResDiscos = Integer.parseInt(Discos);
        String Vinilos = jTextField6.getText();
        int valorResVinilos = Integer.parseInt(Vinilos);

        // Obtener la fila seleccionada en jTable4
        int filaSeleccionada = jTable4.getSelectedRow();

        // Obtener el valor de la columna "idProducto" en la fila seleccionada
        int idProducto = (int) jTable4.getValueAt(filaSeleccionada, 0);

        // Restar el valor de JTextField5 a la columna "precio" en jTable2
        for (int i = 0; i < jTable2.getRowCount(); i++) {
            int idProductoEnTabla = (int) jTable2.getValueAt(i, 0);
            if (idProductoEnTabla == idProducto) {
                int precioActual = (int) jTable2.getValueAt(i, 1);
                int nuevoPrecio = precioActual - valorResDiscos;
                jTable2.setValueAt(nuevoPrecio, i, 1);
            }
        }
        // Restar el valor de JTextField5 a la columna "precio" en jTable2
        for (int i = 0; i < jTable2.getRowCount(); i++) {
            int idProductoEnTabla = (int) jTable2.getValueAt(i, 0);
            if (idProductoEnTabla == idProducto) {
                int precioActual = (int) jTable2.getValueAt(i, 1);
                int nuevoPrecio = precioActual - valorResVinilos;
                jTable2.setValueAt(nuevoPrecio, i, 1);
            }
        }
    }
     */

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18ActionPerformed
    // Declaración de la variable jButton18Pressed
    private boolean jButton18Pressed = false;

    /**
     * Evento que se ejecuta al hacer clic en el botón jButton18. Realiza el
     * cálculo de la suma de existencia y establece la variable jButton18Pressed
     * a true.
     */
    private void jButton18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseClicked
        calcularSumaExistencia();
        jButton18Pressed = true;
    }//GEN-LAST:event_jButton18MouseClicked

    private void jButton20MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20MouseMoved

    private void jButton20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseClicked
        jTabbedPane4.setSelectedIndex(4);
    }//GEN-LAST:event_jButton20MouseClicked

    private void jButton20MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20MouseExited

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21MouseMoved

    private void jButton21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseClicked
        jTabbedPane4.setSelectedIndex(1);
    }//GEN-LAST:event_jButton21MouseClicked

    private void jButton21MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21MouseExited

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        mostrarVentas();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed
    /**
     * Evento que se ejecuta y muestra el jFrameProductos.
     */
    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        Productos prod = new Productos();
        prod.setVisible(true);
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed
    /**
     * Evento que se ejecuta y muestra el jFrameProveedores.
     */
    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        Proveedores prov = new Proveedores();
        prov.setVisible(true);
    }//GEN-LAST:event_jButton19ActionPerformed
    /**
     * Evento que se ejecuta y muestra el jFrameClientes.
     */
    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        Clientes cli = new Clientes();
        cli.setVisible(true);
    }//GEN-LAST:event_jButton24ActionPerformed
    /**
     * Evento que se ejecuta al hacer clic en el botón jButton23. Realiza la
     * inserción de una nueva compra en la base de datos utilizando los valores
     * de los campos correspondientes.
     */
    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // Obtener los valores de los campos
        String idCompra = jTextField8.getText();
        String idProducto = jComboBox2.getSelectedItem().toString();
        String idProveedor = jComboBox3.getSelectedItem().toString();
        int cantidad = Integer.parseInt(jTextField9.getText());

        // Obtener la fecha actual del jLabel6
        String fecha = jLabel6.getText();

        // Calcular el total utilizando el código anterior
        double precioProducto = buscarPrecioProducto();
        double total = cantidad * precioProducto;

        // Crear la consulta SQL INSERT
        String query = "INSERT INTO Compras (ID_Compra, ID_Producto, ID_Proveedor, Cantidad, Fecha, Total) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
            String usuarioDB = "sa";
            String contraseñaDB = "1234";
            Connection con = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, idCompra);
            statement.setString(2, idProducto);
            statement.setString(3, idProveedor);
            statement.setInt(4, cantidad);
            statement.setString(5, fecha);
            statement.setDouble(6, total);
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Compra agregada correctamente a la base de datos.");
            statement.close();
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al agregar la compra a la base de datos: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton23ActionPerformed
    /**
     * Evento que se ejecuta al hacer clic en el botón jButton25. Muestra las
     * compras realizadas en la tabla jTable3.
     */
    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
        mostrarCompras();
    }//GEN-LAST:event_jButton25ActionPerformed
    /**
     * Evento que se ejecuta al hacer clic en el botón jButton25. Muestra las
     * compras realizadas en la tabla jTable3.
     */
    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
String idVenta = jTextField12.getText();
String fecha = jTextField10.getText();

try {
    // Establecer la conexión con la base de datos SQL Server
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";
    Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Preparar la llamada al procedimiento almacenado
    String procedimiento = "{call BuscarVentas(?, ?)}";
    CallableStatement cstmt = conexión.prepareCall(procedimiento);

    // Configurar los parámetros del procedimiento almacenado
    cstmt.setString(1, idVenta.isEmpty() ? null : idVenta);
    cstmt.setString(2, fecha.isEmpty() ? null : fecha);

    // Ejecutar la llamada al procedimiento almacenado
    ResultSet resultado = cstmt.executeQuery();

    DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
    model.setRowCount(0);

    // Verificar si se encontraron ventas y agregarlas a la tabla
    boolean encontradas = false;
    while (resultado.next()) {
        String ventaId = resultado.getString("ID_Venta");
        String clienteId = resultado.getString("ID_Cliente");
        String empleadoId = resultado.getString("ID_Empleado");
        String productoId = resultado.getString("ID_Producto");
        String fechaVenta = resultado.getString("FechaVenta");
        int cantidad = resultado.getInt("Cantidad");
        double total = resultado.getDouble("Total");

        model.addRow(new Object[]{ventaId, clienteId, empleadoId, productoId, fechaVenta, cantidad, total});
        encontradas = true;
    }

    if (!encontradas) {
        if (!idVenta.isEmpty() && !fecha.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontró ninguna venta con el ID y fecha especificados.");
        } else if (!idVenta.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontró ninguna venta con el ID especificado.");
        } else if (!fecha.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontraron ventas para la fecha especificada.");
        } else {
            JOptionPane.showMessageDialog(null, "No se encontraron ventas.");
        }
    }

    resultado.close();
    cstmt.close();
    conexión.close();
} catch (Exception ex) {
    ex.printStackTrace();
}
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed
    /**
     * Evento que se ejecuta al hacer clic en el botón jButton28. Actualiza una
     * venta en la base de datos según los criterios especificados en los campos
     * jTextField12, jTextField10 y jTextField11. Muestra un mensaje de éxito o
     * error y actualiza el valor en la tabla jTable3.
     */
    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
String idVenta = jTextField12.getText();
String fecha = jTextField10.getText();
String cantidadText = jTextField11.getText();
int cantidad = 0;

if (idVenta.isEmpty()) {
    JOptionPane.showMessageDialog(null, "Por favor, ingrese el ID de Venta.");
    return;
}

int camposVacios = 0;
if (fecha.isEmpty()) {
    camposVacios++;
}
if (cantidadText.isEmpty()) {
    camposVacios++;
} else {
    try {
        cantidad = Integer.parseInt(cantidadText);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "El valor de cantidad no es válido.");
        return;
    }
}

if (camposVacios >= 2) {
    JOptionPane.showMessageDialog(null, "Debe completar al menos 2 campos.");
    return;
}

try {
    // Establecer la conexión con la base de datos SQL Server
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";
    Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Llamar al procedimiento almacenado
    String procedimiento = "{call ActualizarVenta(?, ?, ?)}";
    CallableStatement cstmt = conexión.prepareCall(procedimiento);
    cstmt.setString(1, idVenta);
    cstmt.setString(2, fecha.isEmpty() ? null : fecha);
    cstmt.setInt(3, cantidadText.isEmpty() ? null : cantidad);

    boolean hadResults = cstmt.execute();

    if (!hadResults) {
        JOptionPane.showMessageDialog(null, "No se encontró la venta con el ID especificado.");
    } else {
        // La venta se actualizó correctamente
        JOptionPane.showMessageDialog(null, "Venta actualizada correctamente.");

        // Actualizar la tabla jTable3 si es necesario
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        int rowCount = model.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String ventaId = model.getValueAt(i, 0).toString();
            if (ventaId.equals(idVenta)) {
                if (!fecha.isEmpty()) {
                    model.setValueAt(fecha, i, 4);
                }
                if (!cantidadText.isEmpty()) {
                    double total = cantidad * BuscarPrecioVentas(); // Actualizar el total
                    model.setValueAt(cantidad, i, 5);
                    model.setValueAt(total, i, 6);
                }
                break;
            }
        }
    }

    cstmt.close();
    conexión.close();
} catch (Exception ex) {
    ex.printStackTrace();
}
    }//GEN-LAST:event_jButton28ActionPerformed
    /**
     * Evento que se ejecuta al hacer clic en el botón jButton28. Actualiza una
     * venta en la base de datos según los criterios especificados en los campos
     * jTextField12, jTextField10 y jTextField11. Muestra un mensaje de éxito o
     * error y actualiza el valor en la tabla jTable3.
     */
    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
String idCompra = jTextField13.getText();

if (idCompra.isEmpty()) {
    JOptionPane.showMessageDialog(null, "Por favor, ingrese el ID de la compra.");
    return;
}

try {
    // Establecer la conexión con la base de datos SQL Server
    String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=VentaDiscosVinilos;encrypt=false;";
    String usuarioDB = "sa";
    String contraseñaDB = "1234";
    Connection conexión = DriverManager.getConnection(jdbcURL, usuarioDB, contraseñaDB);

    // Llamar al procedimiento almacenado para consultar la compra por su ID
    String procedimiento = "{call ConsultarCompraPorID(?)}";
    CallableStatement cstmt = conexión.prepareCall(procedimiento);
    cstmt.setString(1, idCompra);
    ResultSet resultSet = cstmt.executeQuery();

    if (resultSet.next()) {
        // La compra existe, obtener los datos necesarios
        String idProveedor = resultSet.getString("ID_Proveedor");
        String idProducto = resultSet.getString("ID_Producto");
        int cantidad = resultSet.getInt("Cantidad");
        String fecha = resultSet.getString("Fecha");
        double total = resultSet.getDouble("Total");

        // Crear un modelo de tabla para jTable5
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Compra");
        model.addColumn("ID Proveedor");
        model.addColumn("ID Producto");
        model.addColumn("Cantidad");
        model.addColumn("Fecha");
        model.addColumn("Total");

        // Agregar la fila con los datos de la compra
        model.addRow(new Object[]{idCompra, idProveedor, idProducto, cantidad, fecha, total});

        // Asignar el modelo de tabla a jTable5
        jTable5.setModel(model);
    } else {
        JOptionPane.showMessageDialog(null, "No se encontró la compra con el ID especificado.");
    }

    resultSet.close();
    cstmt.close();
    conexión.close();
} catch (Exception ex) {
    ex.printStackTrace();
}

    }//GEN-LAST:event_jButton26ActionPerformed
    /**
     * Método auxiliar para buscar el ID del producto en la tabla jTable3 según
     * el ID de venta.
     *
     * @return El ID del producto encontrado o null si no se encuentra.
     */
    private String buscarIdProducto() {
        String idVenta = jTextField12.getText();
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        int rowCount = model.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            String ventaId = model.getValueAt(i, 0).toString();
            String productoId = model.getValueAt(i, 3).toString();

            if (ventaId.equals(idVenta)) {
                return productoId;
            }
        }

        return null;
    }

    /**
     * Busca y devuelve el precio de una venta en base al ID de venta
     * especificado. El precio se obtiene buscando en la tabla jTable3 y
     * jTable2.
     *
     * @return El precio de la venta o 0.0 si no se encuentra el precio o el
     * producto.
     */
    private double BuscarPrecioVentas() {
        String idVenta = jTextField12.getText();
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        int rowCount = model.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            String ventaId = model.getValueAt(i, 0).toString();
            String productoId = model.getValueAt(i, 3).toString();

            if (ventaId.equals(idVenta)) {
                String idProducto = model.getValueAt(i, 3).toString();
                double precioProducto = 0.0;
                int row = -1;
                for (int j = 0; j < jTable2.getRowCount(); j++) {
                    String producto = jTable2.getValueAt(j, 0).toString();
                    if (producto.equals(idProducto)) {
                        System.out.println("Encontrado producto: " + producto); // Rastreando
                        try {
                            precioProducto = Double.parseDouble(jTable2.getValueAt(j, 4).toString());
                            System.out.println("Precio del producto: " + precioProducto);// Rastreando
                            row = j;
                            break;
                        } catch (NumberFormatException e) {
                            System.out.println("Error al convertir el precio del producto a double.");
                            e.printStackTrace();
                        }
                    }
                }

                if (row != -1) {
                    return precioProducto;
                } else {
                    JOptionPane.showMessageDialog(null, "El producto seleccionado no está disponible.", "Error", JOptionPane.ERROR_MESSAGE);
                    return 0.0;
                }
            }
        }

        return 0.0;
    }

    /**
     * Busca y devuelve el precio de un producto en base al ID de producto
     * seleccionado en jComboBox2. El precio se busca en la tabla jTable2.
     *
     * @return El precio del producto o 0.0 si no se encuentra el producto.
     */
    private double buscarPrecioProducto() {
        // Obtener el valor de jComboBox2 (ID_Producto)
        String idProducto = jComboBox2.getSelectedItem().toString();

        // Buscar el precio del producto en la Tabla Productos usando el ID_Producto
        double precioProducto = 0.0;
        int row = -1;
        for (int i = 0; i < jTable2.getRowCount(); i++) {
            String producto = jTable2.getValueAt(i, 0).toString();
            if (producto.equals(idProducto)) {
                precioProducto = Double.parseDouble(jTable2.getValueAt(i, 4).toString()); // Columna "Precio" en jTable2
                row = i;
                break;
            }
        }

        // Verificar si se encontró el producto en la Tabla Productos
        if (row != -1) {
            return precioProducto;
        } else {
            // El producto no se encontró en la jTable2
            JOptionPane.showMessageDialog(null, "El producto seleccionado no está disponible.", "Error", JOptionPane.ERROR_MESSAGE);
            return 0.0;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Opciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Opciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Opciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Opciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Opciones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables

}
